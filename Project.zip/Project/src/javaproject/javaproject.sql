-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Jan 23, 2022 at 07:37 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `javaproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `cargo_book_flight`
--

CREATE TABLE `cargo_book_flight` (
  `c_id` int(6) NOT NULL,
  `cargo_name` varchar(122) NOT NULL,
  `description` varchar(122) NOT NULL,
  `departure` varchar(122) NOT NULL,
  `arrival` varchar(122) NOT NULL,
  `class` varchar(122) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cargo_ready` varchar(122) NOT NULL,
  `desired_date` varchar(122) NOT NULL,
  `confirm_brand` varchar(122) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cargo_book_flight`
--

INSERT INTO `cargo_book_flight` (`c_id`, `cargo_name`, `description`, `departure`, `arrival`, `class`, `quantity`, `cargo_ready`, `desired_date`, `confirm_brand`, `created_at`) VALUES
(1, 'a', 'q', 'q', 'q', '', 1, 'q', 'q', 'q', '2022-01-18 17:44:20.538336'),
(2, 'safdar', 'animal', 'Faisalabad', 'Gawadar', 'Special Cargo', 1, '12/22/2021', '12/22/2021', 'PIA ', '2022-01-20 21:16:16.376665'),
(3, 'q', 'q', 'Faisalabad', 'Lahore', 'General Cargo', 1, '1', '2', 'AirBlue', '2022-01-20 22:23:42.295820'),
(4, 'q', 'q', 'Faisalabad', 'Lahore', 'Special Cargo', 1, 'q', 'q', 'AirBlue', '2022-01-20 22:25:49.258499'),
(5, 'q', 'q', 'Faisalabad', 'Lahore', 'Special Cargo', 2, '11', '12', 'AirBlue', '2022-01-20 22:26:18.371088'),
(6, '1', '2', 'Faisalabad', 'Lahore', 'Special Cargo', 6, '7', '8', 'Serene Air', '2022-01-21 21:58:44.029537'),
(7, '1', '2', 'Faisalabad', 'Lahore', 'Special Cargo', 6, '7', '8', 'PIA ', '2022-01-21 22:03:35.990286'),
(8, '1', '2', 'Faisalabad', 'Lahore', 'Special Cargo', 6, '7', '8', 'AirBlue', '2022-01-21 22:05:55.052254'),
(9, '1', '2', 'Faisalabad', 'Lahore', 'Special Cargo', 6, '7', '8', 'AirBlue', '2022-01-21 22:09:28.078624'),
(10, '1', '2', 'Faisalabad', 'Lahore', 'Special Cargo', 6, '7', '8', 'AirBlue', '2022-01-21 22:11:29.985250'),
(11, '1', '2', 'Faisalabad', 'Lahore', 'Special Cargo', 6, '7', '8', 'Serene Air', '2022-01-21 22:13:31.221693'),
(12, '1', '1', 'Faisalabad', 'Lahore', 'Special Cargo', 1, '12/12/2021', '12/21/2/2', 'Qatar Airways', '2022-01-23 16:41:24.166095'),
(13, 'q1', 'q1', 'Lahore', 'Faisalabad', 'Special Cargo', 2, 'kllklk22', '8798', 'PIA ', '2022-01-23 18:32:50.815793');

-- --------------------------------------------------------

--
-- Table structure for table `dom_book_flight`
--

CREATE TABLE `dom_book_flight` (
  `bf_id` int(11) NOT NULL,
  `full_name` varchar(122) NOT NULL,
  `passport` varchar(122) NOT NULL,
  `depart` varchar(122) NOT NULL,
  `arrival` varchar(122) NOT NULL,
  `cnic` varchar(122) NOT NULL,
  `class` varchar(122) NOT NULL,
  `seat_num` varchar(122) NOT NULL,
  `profession` varchar(122) NOT NULL,
  `Confirm_b` varchar(122) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dom_book_flight`
--

INSERT INTO `dom_book_flight` (`bf_id`, `full_name`, `passport`, `depart`, `arrival`, `cnic`, `class`, `seat_num`, `profession`, `Confirm_b`, `created_at`) VALUES
(1, 'qwq', '17987', 'jkjh', 'uuh', '81wo', '', '192u1', '19uj', '', '2022-01-16 20:15:45.357886'),
(2, 'asqw', 'qwqw', 'qwq1', 'qws2', '12qwwq', '', '122a', 'sas1', '', '2022-01-16 20:34:39.279326'),
(3, 'aa', '11q', '121q', '12q', '122', '', '1qq', '12q', '', '2022-01-16 20:41:48.448423'),
(4, 'qq', '11', 'qq', 'qq', '11q', '', 'qa1', '1q', '', '2022-01-16 20:56:15.852235'),
(5, 'qq', '11', 'qq11', 'qqaa1', 'qqq', '', 'qq1', 'qq1', '', '2022-01-16 20:57:08.219065'),
(6, 'aa', '11', '11', '11', 'qq', '', '11', '11', '', '2022-01-16 21:00:22.361064'),
(7, 'yasir', 'asqs1', 'fsd', 'lhr', '232312321', 'sun.awt.windows.WToolkit@738a4af0', 'asasq11', 'Bscs', '', '2022-01-19 17:42:58.617810'),
(8, 'qq', 'qq', '1', 'a', '11', 'Premium Class', '1qqq', 'qw2', '', '2022-01-19 18:34:22.616068'),
(9, 'hanzla aziz', '11212s', 'faisalabd', 'lahore ', '2323232', 'Business Class', '2', 'developer', '', '2022-01-19 18:37:20.801471'),
(10, '', '', '', '', '', 'Select Class', '', '', '', '2022-01-19 19:08:16.465724'),
(11, 'yasir', 'sdhjsd', 'fsd', 'lhe', '211313', 'Business Class', 'sun.awt.windows.WToolkit@738a4af0', 'saasas', '', '2022-01-19 19:23:02.242193'),
(12, 'a', 'a', 'a', 'a', '1', 'First Class', '1', 'a', '', '2022-01-19 20:01:16.054543'),
(13, '', '', '', '', '', 'Select Class', '', '', '', '2022-01-19 20:23:03.474080'),
(14, 'Hanzla Aziz', '11-aa1', 'Fais', 'Lhr', '33100-8054165-3', 'Premium Class', '1s3', 'Malsao', '', '2022-01-19 20:48:07.972007'),
(15, 'a', 'q', 'q', 'q', '212', 'Economy Class', 'qq', 'aa', '', '2022-01-19 20:50:11.764735'),
(16, '', '', '', '', '', 'Select Class', '', '', '', '2022-01-20 19:14:01.128696'),
(17, 'hanzla', 'aass1', 'Lahore', 'Gawadar', '12123232', 'Premium Class', 'aas1', 'sds', '', '2022-01-20 21:09:48.861243'),
(18, 'dom', '11', 'Lahore', 'Faisalabad', '11111', 'Premium Class', 'wq1', 'q', '', '2022-01-20 22:05:27.410990'),
(19, 'a', 'a', 'Faisalabad', 'Lahore', '11', 'Premium Class', 'qa', 'qq', '', '2022-01-20 22:09:13.370182'),
(20, 'qq', '12', 'Faisalabad', 'Lahore', '12', 'First Class', '12', '12s', '', '2022-01-20 22:27:27.587513'),
(21, 'q', '1q', 'Faisalabad', 'Lahore', '12121', 'First Class', '1q', 'd', '', '2022-01-21 19:16:45.258059'),
(22, 'a', 'a', 'Faisalabad', 'Lahore', '11', 'Premium Class', '1', 's', 'PIA ', '2022-01-21 19:59:05.640099'),
(23, 'a', 'a', 'Faisalabad', 'Lahore', '11', 'Premium Class', '1', 's', 'PIA ', '2022-01-21 19:59:05.647620'),
(24, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '6', '7', 'PIA ', '2022-01-21 20:07:40.212072'),
(25, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '6', '7', 'PIA ', '2022-01-21 20:07:40.216636'),
(26, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:08:43.606448'),
(27, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:08:43.613787'),
(28, 'Hanzla', '22112-1111', 'Faisalabad', 'Lahore', '33100-8054165-3', 'Premium Class', '12', 'developer', 'PIA ', '2022-01-21 20:23:02.537578'),
(29, 'Hanzla', '22112-1111', 'Faisalabad', 'Lahore', '33100-8054165-3', 'Premium Class', '12', 'developer', 'PIA ', '2022-01-21 20:23:02.543139'),
(30, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:32:02.671385'),
(31, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:32:02.679088'),
(32, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:36:10.716095'),
(33, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:36:10.723173'),
(34, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:38:02.356304'),
(35, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:38:02.363833'),
(36, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:41:18.834095'),
(37, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:41:18.842663'),
(38, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:42:43.413329'),
(39, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:42:43.420882'),
(40, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:44:09.148704'),
(41, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:44:09.153184'),
(42, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:47:17.653392'),
(43, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:47:17.661335'),
(44, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:48:51.067929'),
(45, '1', '2', 'Faisalabad', 'Lahore', '5', 'Premium Class', '7', '8', 'PIA ', '2022-01-21 20:48:51.073275'),
(46, 'q', 'q', 'Faisalabad', ' ', '1', 'Premium Class', 'q', 'q', 'PIA ', '2022-01-21 21:10:06.584571'),
(47, 'q', 'q', 'Faisalabad', ' ', '1', 'Premium Class', 'q', 'q', 'PIA ', '2022-01-21 21:10:06.592306'),
(48, '1', '2', 'Faisalabad', 'Chitral', '5', 'First Class', '7', '8', 'PIA ', '2022-01-23 09:16:23.776038'),
(49, '1', '2', 'Faisalabad', 'Chitral', '5', 'First Class', '7', '8', 'PIA ', '2022-01-23 09:16:23.784638'),
(50, '1', '2', 'Faisalabad', 'Multan', '5', 'First Class', '7', '8', 'PIA ', '2022-01-23 15:03:24.834264'),
(51, '1', '2', 'Faisalabad', 'Multan', '5', 'First Class', '7', '8', 'PIA ', '2022-01-23 15:03:24.849862'),
(52, 'yasir', '1', 'Faisalabad', 'Multan', '333', 'Premium Class', '3', '2', 'PIA ', '2022-01-23 18:30:22.879964'),
(53, 'yasir', '1', 'Faisalabad', 'Multan', '333', 'Premium Class', '3', '2', 'PIA ', '2022-01-23 18:30:22.891345'),
(54, 'a', 'qa00', 'Faisalabad', 'Chitral', '232131923', 'Premium Class', '2', 'sdn', 'PIA ', '2022-01-23 18:37:00.252632'),
(55, 'a', 'qa00', 'Faisalabad', 'Chitral', '232131923', 'Premium Class', '2', 'sdn', 'PIA ', '2022-01-23 18:37:00.259064');

-- --------------------------------------------------------

--
-- Table structure for table `inter_book_flight`
--

CREATE TABLE `inter_book_flight` (
  `bf_id` int(6) NOT NULL,
  `full_name` varchar(122) NOT NULL,
  `passport` varchar(122) NOT NULL,
  `depart` varchar(122) NOT NULL,
  `arrival` varchar(122) NOT NULL,
  `cnic` varchar(122) NOT NULL,
  `class` varchar(122) NOT NULL,
  `seat_num` varchar(11) NOT NULL,
  `profession` varchar(122) NOT NULL,
  `Confirm_b` varchar(122) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inter_book_flight`
--

INSERT INTO `inter_book_flight` (`bf_id`, `full_name`, `passport`, `depart`, `arrival`, `cnic`, `class`, `seat_num`, `profession`, `Confirm_b`, `created_at`) VALUES
(1, 'qq', '11', 'qq', '11q', '11', '', 'qq1', 'qq', '', '2022-01-16 21:10:05.439994'),
(2, 'q', 'q', 'Lahore', 'Faisalabad', '1', 'Premium Class', '1q', 'a', '', '2022-01-20 22:19:42.619596'),
(3, 'q', 'q1', 'Faisalabad', 'Lahore', '11', 'First Class', '1q', 'ww', '', '2022-01-20 22:26:55.531080'),
(4, 'Hanzla Aziz', '12aa', 'Faisalabad', 'Lahore', '1221212121210212', 'Premium Class', '12121', 'developwe', 'PIA ', '2022-01-21 19:48:46.696628'),
(5, 'Yasir', '12', 'France', 'Dubia', '121212121212', 'Economy Class', '2', '2', 'PIA ', '2022-01-21 21:08:47.537021'),
(6, 'q', 'q', 'Pakistan', 'Dubia', '2', 'Premium Class', '1', '2', 'PIA ', '2022-01-21 21:42:34.632669'),
(7, 'BILLA BADSHAH', 'U1696121 / ORDINARY PASSPORT', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at BadShah Associates', 'Qatar Airways', '2022-01-21 22:21:14.672796'),
(8, 'BILLA BADSHAH', 'U16 / ORDINARY PASSPORT', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at BA', 'Qatar Airways', '2022-01-21 22:22:45.249925'),
(9, 'BILLA BADSHAH', 'U16-866Q/  PASSPORT', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at BA', 'Qatar Airways', '2022-01-21 22:23:34.044152'),
(10, 'BILLA BADSHAH', 'U16-866Q PASSPORT', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at BA', 'Qatar Airways', '2022-01-21 22:23:51.013264'),
(11, 'BILLA BADSHAH', 'U16-86', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at BA', 'Qatar Airways', '2022-01-21 22:24:04.000502'),
(12, 'BILLA BADSHAH', 'bU1696121', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at Audi', 'Qatar Airways', '2022-01-21 22:26:14.807772'),
(13, 'BILLA BADSHAH', 'AU1696121-Ordinary', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at Audi', 'Qatar Airways', '2022-01-21 22:26:36.398385'),
(14, 'BILLA BADSHAH', 'AU1696121-Ord', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at Audi', 'Qatar Airways', '2022-01-21 22:26:44.972176'),
(15, 'BILLA BADSHAH', 'AU1696121-Ord', 'Pakistan', 'Saudia Arabia', '33100-8054165-3', 'Business Class', '1', 'CEO at Audi', 'Qatar Airways', '2022-01-21 22:26:53.329933'),
(16, 'Yasir', 'PP1234567', 'France', 'Saudia Arabia', '33100-8054-165-3', 'Economy Class', '2', 'Developer', 'Emirates Airline', '2022-01-23 18:23:38.276648');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `full_name` varchar(122) NOT NULL,
  `email` varchar(122) NOT NULL,
  `cnic` varchar(122) NOT NULL,
  `password` varchar(122) NOT NULL,
  `contact_no` varchar(122) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `full_name`, `email`, `cnic`, `password`, `contact_no`, `created_at`) VALUES
(1, 'Hanzla Aziz', 'um12@gmail.com', '21324324', '233424', '23432432', '2022-01-14 21:04:12.552640'),
(2, 'hhh', 'aa', '111', '1', '2', '2022-01-14 21:24:43.641357'),
(3, 'Mouzam', 'malkimouzam5', '3354e34', '123', '999878776', '2022-01-15 11:14:48.992782'),
(4, 'ali', 'ali@gmail.com', '123456', '12A', '12344', '2022-01-16 14:54:34.821095'),
(5, 'MuhammadYasir', 'yasirrana818@gmail.com', '33100121212', 'a', '1212', '2022-01-16 14:57:50.184822'),
(6, 'Muhammad Yasir', 'yasirrana818@gmail.com', '33110201021021', 'a', '231233123', '2022-01-16 14:58:32.037754'),
(7, 'hnzla', 'y@gmail.com', '1234567890', '1', '03072457573', '2022-01-16 18:20:45.649676'),
(8, 'qa', 'qq', '122', '1', '123232323', '2022-01-20 22:28:17.969443'),
(9, '', '', '', '', '', '2022-01-21 10:54:49.990551'),
(10, '', '', '', '', '', '2022-01-21 10:54:55.098913'),
(11, 'q', 'q', 'q', 'q', 'q', '2022-01-23 15:34:22.056434'),
(12, '1', '2', '3', '4', '5', '2022-01-23 16:55:48.132134'),
(13, '1', '2', '3', '4', '5', '2022-01-23 16:57:22.099065'),
(14, 'Yasir', 'yasirrana818@gmail.com', '33100-8054165-3', '1', '03127869726', '2022-01-23 18:12:27.332669'),
(15, 'Yasir', 'yasirrana818@gmail.com', '33100-8054165-3', '1', '03127869726', '2022-01-23 18:13:36.351637'),
(16, 'hnzla', 'um12@gmail.com', '33100-8054165-3', '123', '03127869726', '2022-01-23 18:21:18.412977');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cargo_book_flight`
--
ALTER TABLE `cargo_book_flight`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `dom_book_flight`
--
ALTER TABLE `dom_book_flight`
  ADD PRIMARY KEY (`bf_id`);

--
-- Indexes for table `inter_book_flight`
--
ALTER TABLE `inter_book_flight`
  ADD PRIMARY KEY (`bf_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo_book_flight`
--
ALTER TABLE `cargo_book_flight`
  MODIFY `c_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `dom_book_flight`
--
ALTER TABLE `dom_book_flight`
  MODIFY `bf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `inter_book_flight`
--
ALTER TABLE `inter_book_flight`
  MODIFY `bf_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
