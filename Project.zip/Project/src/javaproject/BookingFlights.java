package javaproject;
import java.text.DateFormat;
import java.util.Date;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
public class BookingFlights implements ActionListener{
	
	private static JTextField FullName;
	private static JTextField PassPort;
	private static JComboBox Departure;
	private static JComboBox Arival;
	private static JTextField Cnic;
	private static JTextField SeatNumber;
	private static JTextField Profession;
	private static JTextField CargoName;
	private static JTextField Quantity;
	private static JTextField Cargodescription;
	private static JComboBox classs;
	private static JTextField CargoReady;
	private static JTextField DesiredDate;
	private static JTextField Description;
	public static  JTextField ConfirmBrand;
	private static JButton LetsGo;
	private static JButton LetsGo2;
	private static JButton LetsCargo;
	private static JComboBox dropdown;
	private static JLabel dropdown1;
	private static JLabel dropdown2;
	private static JLabel dropdown3;
// Frames
	public static JFrame DomFlightForm;
	public static JFrame IntFlightForm;
	public static JFrame CargoFlightForm;
	public static JFrame DomTicketFrame;
	public static JFrame IntTicketFrame;
	public static JFrame CargoTicket;
	public static JFrame DomesticTicket;
	public static JFrame InternationalTicket;
	
	public static void DomFlightForm() {
		Login.DomesBrandFrame.setVisible(false);
		DomFlightForm = new JFrame();
		
		JPanel panel = new JPanel();

		Color framecolor = Color.decode("#9881F5");
		panel.setBackground(framecolor);
		
		LetsGo = new JButton("Lets Fly !");
		panel.setBorder(BorderFactory.createEmptyBorder(0,20,10,20));
		DomFlightForm.setSize(500,710);
		LetsGo.addActionListener(new BookingFlights());
		LetsGo.setBackground(Color.decode("#F1F0FF"));
		LetsGo.setForeground(Color.BLACK);
		LetsGo.setBorderPainted(false);
		
		JLabel BookFlightLabel = new JLabel("B  o  o  k  Flight ");
		JLabel FullNameLabel = new JLabel("Full Name ");
		JLabel PassportLabel = new JLabel("Passport Number ( PPXXXXXXX ) ");
		dropdown1=new JLabel("<html>Departure City</html>");
		dropdown2=new JLabel("<html>Arrival City</html>");
		JLabel CnicLabel = new JLabel("CNIC  ( XXXXX-XXXXXXX-X )");
		dropdown3=new JLabel("<html>Class</html>");
		JLabel SeatLabel = new JLabel("Number of Seats ");
		JLabel ProfessionLabel = new JLabel("Profession");
		JLabel SelectBrandLabel = new JLabel("Confirm Brand"); 
		BookFlightLabel.setPreferredSize(new Dimension(390, 100));
		Font bigFont = BookFlightLabel.getFont().deriveFont(Font.PLAIN, 50f);
		BookFlightLabel.setFont(bigFont);
		FullName = new JTextField(45);
		PassPort = new JTextField(45);
		String select1[]={" ","Economy Class","Premium Class","Business Class","First Class"}; 
		dropdown=new JComboBox(select1);
		dropdown.setBackground(Color.white);
		dropdown.setBounds(700,700,700,700);
		String select2[]={" ","Faisalabad","Lahore","Gawadar","Islamabad"}; 
		Departure = new JComboBox(select2);
		Departure.setBackground(Color.white);
		Departure.setBounds(700,700,700,700);
		String select3[]={" ","Karachi","Chitral","Quetta","Multan"}; 
		Arival = new JComboBox(select3);
		Arival.setBackground(Color.white);
		Arival.setBounds(700,700,700,700);
		Cnic = new JTextField(45);
		SeatNumber = new JTextField(45);
		Profession = new JTextField(45);
		ConfirmBrand = new JTextField(45);
		FullName.setPreferredSize(new Dimension(150, 30));
		PassPort.setPreferredSize(new Dimension(150, 30));
		Departure.setPreferredSize(new Dimension(410, 30));
		Arival.setPreferredSize(new Dimension(410, 30));
		Cnic.setPreferredSize(new Dimension(150, 30));
		dropdown.setPreferredSize(new Dimension(410, 30));
		SeatNumber.setPreferredSize(new Dimension(150, 30));
		Profession.setPreferredSize(new Dimension(150, 30));
		ConfirmBrand.setPreferredSize(new Dimension(150, 30));
		LetsGo.setPreferredSize(new Dimension(150, 30));
		panel.add(BookFlightLabel);
		panel.add(FullNameLabel);
		panel.add(FullName);
		panel.add(PassportLabel);
		panel.add(PassPort);
		panel.add(dropdown1);
		panel.add(Departure);
		panel.add(dropdown2);
		panel.add(Arival);
		panel.add(CnicLabel);
		panel.add(Cnic);
		panel.add(dropdown3);
		panel.add(dropdown);
		panel.add(SeatLabel);
		panel.add(SeatNumber);
		panel.add(ProfessionLabel);
		panel.add(Profession);
		panel.add(SelectBrandLabel);
		panel.add(ConfirmBrand);
		panel.add(LetsGo);
		DomFlightForm.add(panel, BorderLayout.CENTER);
		DomFlightForm.setVisible(true);
		DomFlightForm.setLocationRelativeTo(null);
		DomFlightForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public static void InterFlightForm() {
		Login.IntBrandFrame.setVisible(false);

		IntFlightForm = new JFrame();
		JPanel panel = new JPanel();
		
		Color framecolor = Color.decode("#9881F5");
		panel.setBackground(framecolor);
		
		LetsGo2 = new JButton("Lets Fly !");
		panel.setBorder(BorderFactory.createEmptyBorder(0,20,10,20));
		LetsGo2.setBackground(Color.decode("#F1F0FF"));
		LetsGo2.setForeground(Color.BLACK);
		LetsGo2.setBorderPainted(false);
		
		IntFlightForm.setSize(500,710);
		LetsGo2.addActionListener(new BookingFlights());
		JLabel BookFlightLabel = new JLabel("B  o  o  k  Flight ");
		JLabel FullNameLabel = new JLabel("Full Name ");
		JLabel PassportLabel = new JLabel("Passport Number ( PPXXXXXXX ) ");
		dropdown1=new JLabel("<html>Departure City</html>");
		dropdown2=new JLabel("<html>Arrival City</html>");
		JLabel CnicLabel = new JLabel("CNIC  ( XXXXX-XXXXXXX-X )");
		dropdown3=new JLabel("<html>Class</html>");
		JLabel SeatLabel = new JLabel("Number of Seats ");
		JLabel ProfessionLabel = new JLabel("Profession");
		JLabel SelectBrandLabel = new JLabel("Confirm Brand"); 
		BookFlightLabel.setPreferredSize(new Dimension(390, 100));
		Font bigFont = BookFlightLabel.getFont().deriveFont(Font.PLAIN, 50f);
		BookFlightLabel.setFont(bigFont);
		FullName = new JTextField(45);
		PassPort = new JTextField(45);
		String select1[]={" ","Economy Class","Premium Class","Business Class","First Class"}; 
		dropdown=new JComboBox(select1);
		dropdown.setBackground(Color.white);
		dropdown.setBounds(700,700,700,700);
		String select2[]={" ","Pakistan","France","Australia","Canada"}; 
		Departure = new JComboBox(select2);
		Departure.setBackground(Color.white);
		Departure.setBounds(700,700,700,700);
		String select3[]={" ","Dubia","America","Saudia Arabia","China"}; 
		Arival = new JComboBox(select3);
		Arival.setBackground(Color.white);
		Arival.setBounds(700,700,700,700);
		Cnic = new JTextField(45);
		SeatNumber = new JTextField(45);
		Profession = new JTextField(45);
		ConfirmBrand = new JTextField(45);
		FullName.setPreferredSize(new Dimension(150, 30));
		PassPort.setPreferredSize(new Dimension(150, 30));
		Departure.setPreferredSize(new Dimension(410, 30));
		Arival.setPreferredSize(new Dimension(410, 30));
		Cnic.setPreferredSize(new Dimension(150, 30));
		dropdown.setPreferredSize(new Dimension(410, 30));
		SeatNumber.setPreferredSize(new Dimension(150, 30));
		Profession.setPreferredSize(new Dimension(150, 30));
		ConfirmBrand.setPreferredSize(new Dimension(150, 30));
		panel.add(BookFlightLabel);
		panel.add(FullNameLabel);
		panel.add(FullName);
		panel.add(PassportLabel);
		panel.add(PassPort);
		panel.add(dropdown1);
		panel.add(Departure);
		panel.add(dropdown2);
		panel.add(Arival);
		panel.add(CnicLabel);
		panel.add(Cnic);
		panel.add(dropdown3);
		panel.add(dropdown);
		panel.add(SeatLabel);
		panel.add(SeatNumber);
		panel.add(ProfessionLabel);
		panel.add(Profession);
		panel.add(SelectBrandLabel);
		panel.add(ConfirmBrand);
		panel.add(LetsGo2);
		IntFlightForm.add(panel, BorderLayout.CENTER);
		IntFlightForm.setVisible(true);
		IntFlightForm.setLocationRelativeTo(null);
		IntFlightForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public static void CargoFlightForm() {
		Login.CargoBrandFrame.setVisible(false);

		CargoFlightForm = new JFrame();
		
		JPanel panel = new JPanel();
		
		Color framecolor = Color.decode("#9881F5");
		panel.setBackground(framecolor);
		
		LetsCargo = new JButton("Lets Cargo !");
		panel.setBorder(BorderFactory.createEmptyBorder(0,20,10,20));
		LetsCargo.setBackground(Color.decode("#F1F0FF"));
		LetsCargo.setForeground(Color.BLACK);
		LetsCargo.setBorderPainted(false);
		CargoFlightForm.setSize(500,710);
		LetsCargo.addActionListener(new BookingFlights());
		JLabel BookFlightLabel = new JLabel("B  o  o  k  Flight ");
		JLabel CargoNameLabel = new JLabel("Cargo Name ");
		JLabel DescriptionLabel = new JLabel("Description ");
		dropdown1=new JLabel("<html>Departure City</html>");
		dropdown2=new JLabel("<html>Arrival City</html>");
		dropdown3=new JLabel("<html>Class</html>");
		JLabel QuantityLabel = new JLabel("Quantity ");
		JLabel CargoreadyLabel = new JLabel("Cargo Is Ready On ( DD/MM/YY ) ");
		JLabel CargoArrivalLabel = new JLabel("Desired Arrival Date ( DD/MM/YY )");
		JLabel SelectBrandLabel = new JLabel("Confirm Brand");
		BookFlightLabel.setPreferredSize(new Dimension(390, 100));
		Font bigFont = BookFlightLabel.getFont().deriveFont(Font.PLAIN, 50f);
		BookFlightLabel.setFont(bigFont);
		CargoName = new JTextField(45);
		Description = new JTextField(45);
		String select1[]={" ","General Cargo","Special Cargo"}; 
		classs=new JComboBox(select1);
		classs.setBackground(Color.white);
		classs.setBounds(700,700,700,700);
		String select2[]={" ","Faisalabad","Lahore","Gawadar","Islamabad"}; 
		Departure = new JComboBox(select2);
		Departure.setBackground(Color.white);
		Departure.setBounds(700,700,700,700);
		String select3[]={" ","Faisalabad","Lahore","Gawadar","Islamabad"}; 
		Arival = new JComboBox(select3);
		Arival.setBackground(Color.white);
		Arival.setBounds(700,700,700,700);
		Quantity = new JTextField(45);
		CargoReady = new JTextField(45);
		DesiredDate = new JTextField(45);
		ConfirmBrand = new JTextField(45);
		CargoName.setPreferredSize(new Dimension(150, 30));
		Description.setPreferredSize(new Dimension(150, 30));
		Departure.setPreferredSize(new Dimension(410, 30));
		Arival.setPreferredSize(new Dimension(410, 30));
		classs.setPreferredSize(new Dimension(410, 30));
		Quantity.setPreferredSize(new Dimension(150, 30));
		CargoReady.setPreferredSize(new Dimension(150, 30));
		DesiredDate.setPreferredSize(new Dimension(150, 30));
		ConfirmBrand.setPreferredSize(new Dimension(150, 30));
		panel.add(BookFlightLabel);
		panel.add(CargoNameLabel);
		panel.add(CargoName);
		panel.add(DescriptionLabel);
		panel.add(Description);
		panel.add(dropdown1);
		panel.add(Departure);
		panel.add(dropdown2);
		panel.add(Arival);
		panel.add(dropdown3);
		panel.add(classs);
		panel.add(QuantityLabel);
		panel.add(Quantity);
		panel.add(CargoreadyLabel);
		panel.add(CargoReady);
		panel.add(CargoArrivalLabel);
		panel.add(DesiredDate);
		panel.add(SelectBrandLabel);
		panel.add(ConfirmBrand);
		panel.add(LetsCargo);
		CargoFlightForm.add(panel, BorderLayout.CENTER);
		CargoFlightForm.setVisible(true);
		CargoFlightForm.setLocationRelativeTo(null);
		CargoFlightForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

		public static void DomesticTicket (String sFrom, String sTo, String sClass, String iAdult, String iChildren, String iInfant, String iInfantt, String sBookingDate, String iPrice)
		{	DomFlightForm.setVisible(false);
			DomesticTicket = new JFrame();
			Container c=DomesticTicket.getContentPane();
			c.setLayout(new BorderLayout());
			
			JPanel Panel2 = new JPanel(null);

			Panel2.setPreferredSize(new Dimension(500,200));

			JLabel LTitle = new JLabel("<html><b><font color=\"#C71585\",size=\"7\">Domestic AirLine Ticket</font></b></html>");
			JLabel Full_name = new JLabel("<html><b><font color=\"#000000\">Full Name:</font></b><font color=\"#778899\">"+ sFrom+"</font></html>" );
			JLabel Pass_p = new JLabel("<html><font color=\"#000000\">PassPort Number &nbsp; : </font><font color=\"#778899\">"+sTo+"</font></html>");
			JLabel D_city = new JLabel("<html><font color=\"#000000\">Departure City  &nbsp; :</font><font color=\"#778899\">"+sClass+"</font></html>" );
			JLabel A_city= new JLabel("<html><font color=\"#000000\">Arrival &nbsp; &nbsp;   : </font><font color=\"#778899\">"+ sBookingDate+"</font></html>" );
			JLabel cnic = new JLabel("<html><font color=\"#000000\">CNIC &nbsp;              :     </font><font color=\"#778899\">"+ iPrice+"</font></html>" );
			JLabel classs = new JLabel("<html><font color=\"#000000\">Class &nbsp;           :</font><font color=\"#778899\">"+iAdult+"</font></html>" );
			JLabel s_num = new JLabel("<html><font color=\"#000000\">Seat Number &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : &nbsp;</font><font color=\"#778899\">"+ iChildren+"</font></html>" );
			JLabel profes = new JLabel("<html><font color=\"#000000\">Profession &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iInfant+"</font></html>" );
			JLabel Conf_b = new JLabel("<html><font color=\"#000000\">Airline &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iInfantt+"</font></html>" );
			JLabel LWishes = new JLabel("<html><body><I><font color=\"#D2B48C\">Have a Safe Flight</font></I></body></html>");
			
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon("D:\\Eclipse\\Eclipse Workspace\\Project\\src\\javaproject\\1.png"));
			label.setBounds(450, 44, 314, 283);
			DomesticTicket.getContentPane().add(label);
			
			JLabel LEmpty = new JLabel("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			JLabel LDemo = new JLabel("<html><U><font color=\"#8FBC8F\">AirLine Reservation System - Developed By</font></U></html>");
			JLabel YASIR=new JLabel("<html><I><font color=\"#8FBC8F\">Muhammad Yasir</font></I></html>");
			JLabel FASIH=new JLabel("<html><I><font color=\"#8FBC8F\">Muhammad Fasih Farooq</font></I></html>");
			JLabel USMAN=new JLabel("<html><I><font color=\"#8FBC8F\">Usman Masood</font></I></html>");
			JLabel label2 = new JLabel("");
			label2.setIcon(new ImageIcon("D:\\Eclipse\\Eclipse Workspace\\Project\\src\\javaproject\\ser.png"));
			label2.setBounds(450, 444, 414, 283);
			label2.setSize(420,220);
			DomesticTicket.getContentPane().add(label2);

			LTitle.setBounds(170,15,500,45);
			Full_name.setBounds(20,80,300,20);
			Pass_p.setBounds(20,125,300,20);
			D_city.setBounds(20,170,300,20);
			A_city.setBounds(20,215,300,20);
			cnic.setBounds(20,260,300,20);
			classs.setBounds(20,305,300,20);
			s_num.setBounds(20,350,300,20);
			profes.setBounds(20,395,300,20);
			Conf_b.setBounds(20,435,300,20);
			
			
			LWishes.setBounds(530,435,300,20);
			LEmpty.setBounds(3,445,1000,20);
			LDemo.setBounds(280,465,300,20);
			YASIR.setBounds(285,485,300,20);
			FASIH.setBounds(285,505,300,20);
			USMAN.setBounds(285,525,300,20);
			
			Panel2.add(LTitle);
			Panel2.add(Full_name);
			Panel2.add(Pass_p);
			Panel2.add(D_city);
			Panel2.add(A_city);
			Panel2.add(cnic);
			Panel2.add(classs);
			Panel2.add(s_num);
			Panel2.add(profes);
			Panel2.add(Conf_b);
			Panel2.add(LWishes);
			Panel2.add(LEmpty);
			Panel2.add(LDemo);
			Panel2.add(YASIR);
			Panel2.add(FASIH);
			Panel2.add(USMAN);

			Color myColor = Color.decode("#EDF4F5");
			Panel2.setBackground(myColor);

			c.add(Panel2, BorderLayout.CENTER);

			DomesticTicket.setSize(700,650);
			DomesticTicket.setVisible(true);
		}
		public static void InternationalTicket (String sFrom, String sTo, String sClass, String iAdult, String iChildren, String iInfant, String iInfantt, String sBookingDate, String iPrice)
		{	
			IntFlightForm.setVisible(false);
			InternationalTicket = new JFrame();
			Container c=InternationalTicket.getContentPane();
			c.setLayout(new BorderLayout());
			
			JPanel Panel2 = new JPanel(null);

			Panel2.setPreferredSize(new Dimension(500,200));

			JLabel LTitle = new JLabel("<html><b><font color=\"#C71585\",size=\"7\">Domestic AirLine Ticket</font></b></html>");
			JLabel Full_name = new JLabel("<html><b><font color=\"#000000\">Full Name:</font></b><font color=\"#778899\">"+ sFrom+"</font></html>" );
			JLabel Pass_p = new JLabel("<html><font color=\"#000000\">PassPort Number &nbsp; : </font><font color=\"#778899\">"+sTo+"</font></html>");
			JLabel D_city = new JLabel("<html><font color=\"#000000\">Departure City  &nbsp; :</font><font color=\"#778899\">"+sClass+"</font></html>" );
			JLabel A_city= new JLabel("<html><font color=\"#000000\">Arrival &nbsp; &nbsp;   : </font><font color=\"#778899\">"+ sBookingDate+"</font></html>" );
			JLabel cnic = new JLabel("<html><font color=\"#000000\">CNIC &nbsp;              :     </font><font color=\"#778899\">"+ iPrice+"</font></html>" );
			JLabel classs = new JLabel("<html><font color=\"#000000\">Class &nbsp;           :</font><font color=\"#778899\">"+iAdult+"</font></html>" );
			JLabel s_num = new JLabel("<html><font color=\"#000000\">Seat Number &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : &nbsp;</font><font color=\"#778899\">"+ iChildren+"</font></html>" );
			JLabel profes = new JLabel("<html><font color=\"#000000\">Profession &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iInfant+"</font></html>" );
			JLabel Conf_b = new JLabel("<html><font color=\"#000000\">Airline &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iInfantt+"</font></html>" );
			JLabel LWishes = new JLabel("<html><body><I><font color=\"#D2B48C\">Have a Safe Flight</font></I></body></html>");
			
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon("D:\\Eclipse\\Eclipse Workspace\\Project\\src\\javaproject\\1.png"));
			label.setBounds(450, 44, 314, 283);
			InternationalTicket.getContentPane().add(label);


			JLabel LEmpty = new JLabel("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			JLabel LDemo = new JLabel("<html><U><font color=\"#8FBC8F\">AirLine Reservation System - Developed By</font></U></html>");
			JLabel YASIR=new JLabel("<html><I><font color=\"#8FBC8F\">Muhammad Yasir</font></I></html>");
			JLabel FASIH=new JLabel("<html><I><font color=\"#8FBC8F\">Muhammad Fasih Farooq</font></I></html>");
			JLabel USMAN=new JLabel("<html><I><font color=\"#8FBC8F\">Usman Masood</font></I></html>");
			JLabel label2 = new JLabel("");
			label2.setIcon(new ImageIcon("D:\\Eclipse\\Eclipse Workspace\\Project\\src\\javaproject\\ser.png"));
			label2.setBounds(450, 444, 414, 283);
			label2.setSize(420,220);
			InternationalTicket.getContentPane().add(label2);

			LTitle.setBounds(170,15,500,45);
			Full_name.setBounds(20,80,300,20);
			Pass_p.setBounds(20,125,300,20);
			D_city.setBounds(20,170,300,20);
			A_city.setBounds(20,215,300,20);
			cnic.setBounds(20,260,300,20);
			classs.setBounds(20,305,300,20);
			s_num.setBounds(20,350,300,20);
			profes.setBounds(20,395,300,20);
			Conf_b.setBounds(20,435,300,20);

			LWishes.setBounds(530,435,300,20);

			LEmpty.setBounds(3,445,1000,20);

			LDemo.setBounds(280,465,300,20);
			YASIR.setBounds(285,485,300,20);
			FASIH.setBounds(285,505,300,20);
			USMAN.setBounds(285,525,300,20);
			
			Panel2.add(LTitle);
			Panel2.add(Full_name);
			Panel2.add(Pass_p);
			Panel2.add(D_city);
			Panel2.add(A_city);
			Panel2.add(cnic);
			Panel2.add(classs);
			Panel2.add(s_num);
			Panel2.add(profes);
			Panel2.add(Conf_b);

			Panel2.add(LWishes);

			Panel2.add(LEmpty);
			Panel2.add(LDemo);

			Panel2.add(YASIR);
			Panel2.add(FASIH);
			Panel2.add(USMAN);
			

			Color myColor = Color.decode("#EDF4F5");
			Panel2.setBackground(myColor);

			c.add(Panel2, BorderLayout.CENTER);
			
			InternationalTicket.setSize(700,650);
			InternationalTicket.setVisible(true);
		}
		public static void CargoTicket (String sFrom, String sTo, String sClass, String iAdult, String iChildren, String iInfant, String iInfantt, String sBookingDate, String iPrice)
		{	
			CargoFlightForm.setVisible(false);
			CargoTicket = new JFrame();
			
			
			Container c=CargoTicket.getContentPane();
			c.setLayout(new BorderLayout());
			
			JPanel Panel2 = new JPanel(null);

			Panel2.setPreferredSize(new Dimension(500,200));

			JLabel LTitle = new JLabel("<html><b><font color=\"#C71585\",size=\"7\">Cargo AirLine Ticket</font></b></html>");
			JLabel Full_name = new JLabel("<html><b><font color=\"#000000\">Cargo Name &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font></b><font color=\"#778899\">"+ sFrom+"</font></html>" );
			JLabel Pass_p = new JLabel("<html><font color=\"#000000\">Description &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+sTo+"</font></html>");
			JLabel D_city = new JLabel("<html><font color=\"#000000\">Departure City &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+sClass+"</font></html>" );
			JLabel A_city= new JLabel("<html><font color=\"#000000\">Arrival City &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+ sBookingDate+"</font></html>" );
			JLabel cnic = new JLabel("<html><font color=\"#000000\">Class &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+ iPrice+"</font></html>" );
			JLabel classs = new JLabel("<html><font color=\"#000000\">Quantity &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iAdult+"</font></html>" );
			JLabel s_num = new JLabel("<html><font color=\"#000000\">Cargo is Ready on &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+ iChildren+"</font></html>" );
			JLabel profes = new JLabel("<html><font color=\"#000000\">Desired Arrival date &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iInfant+"</font></html>" );
			JLabel Conf_b = new JLabel("<html><font color=\"#000000\">Airline &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;</font><font color=\"#778899\">"+iInfantt+"</font></html>" );
			JLabel LWishes = new JLabel("<html><body><I><font color=\"#D2B48C\">Have a Safe Flight</font></I></body></html>");

			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon("D:\\Eclipse\\Eclipse Workspace\\Project\\src\\javaproject\\1.png"));
			label.setBounds(450, 44, 314, 283);
			CargoTicket.getContentPane().add(label);
			
			JLabel LEmpty = new JLabel("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			JLabel LDemo = new JLabel("<html><U><font color=\"#8FBC8F\">AirLine Reservation System - Developed By</font></U></html>");
			JLabel YASIR=new JLabel("<html><I><font color=\"#8FBC8F\">Muhammad Yasir</font></I></html>");
			JLabel FASIH=new JLabel("<html><I><font color=\"#8FBC8F\">Muhammad Fasih Farooq</font></I></html>");
			JLabel USMAN=new JLabel("<html><I><font color=\"#8FBC8F\">Usman Masood</font></I></html>");
			JLabel label2 = new JLabel("");
			label2.setIcon(new ImageIcon("D:\\Eclipse\\Eclipse Workspace\\Project\\src\\javaproject\\ser.png"));
			label2.setBounds(450, 444, 414, 283);
			label2.setSize(420,220);
			CargoTicket.getContentPane().add(label2);

			LTitle.setBounds(170,15,500,45);
			Full_name.setBounds(20,80,300,20);
			Pass_p.setBounds(20,125,300,20);
			D_city.setBounds(20,170,300,20);
			A_city.setBounds(20,215,300,20);
			cnic.setBounds(20,260,300,20);
			classs.setBounds(20,305,300,20);
			s_num.setBounds(20,350,300,20);
			profes.setBounds(20,395,300,20);
			Conf_b.setBounds(20,435,300,20);

			LWishes.setBounds(530,435,300,20);

			LEmpty.setBounds(3,445,1000,20);

			LDemo.setBounds(280,465,500,20);
			YASIR.setBounds(285,485,300,20);
			FASIH.setBounds(285,505,300,20);
			USMAN.setBounds(285,525,300,20);
			
			Panel2.add(LTitle);
			Panel2.add(Full_name);
			Panel2.add(Pass_p);
			Panel2.add(D_city);
			Panel2.add(A_city);
			Panel2.add(cnic);
			Panel2.add(classs);
			Panel2.add(s_num);
			Panel2.add(profes);
			Panel2.add(Conf_b);

			Panel2.add(LWishes);

			Panel2.add(LEmpty);
			Panel2.add(LDemo);

			Panel2.add(YASIR);
			Panel2.add(FASIH);
			Panel2.add(USMAN);

			Color myColor = Color.decode("#EDF4F5");
			Panel2.setBackground(myColor);

			c.add(Panel2, BorderLayout.CENTER);

			CargoTicket.setSize(700,650);
			CargoTicket.setVisible(true);
		}

	public static void DomFormBook() {
		String DFget1 = FullName.getText();
		String DFget2 = PassPort.getText();
		Toolkit DFget3 = Departure.getToolkit();
		Toolkit DFget4 = Arival.getToolkit();
		String DFget5 = Cnic.getText();
		Toolkit DFget6  = dropdown.getToolkit();
		String DFget7 = SeatNumber.getText();
		String DFget8 = Profession.getText();
		String DFget9 = ConfirmBrand.getText();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/javaproject","root","1@");
			Statement st = con.createStatement();
			boolean chck1 = (FullName == null || DFget1.length() == 0 );
			boolean chck2 = (PassPort == null || DFget2.length() == 0 );
			boolean chck3 = (Departure == null );
			boolean chck4 = (Arival == null);
			boolean chck5 = (Cnic == null || DFget5.length() == 0 );
			boolean chck6 = (dropdown == null);
			boolean chck7 = (SeatNumber == null || DFget7.length() == 0 );
			boolean chck8 = (Profession == null || DFget8.length() == 0 );
			if(chck1||chck2||chck3||chck4||chck5||chck6||chck7||chck8) {
	         	JOptionPane.showMessageDialog(null, "Kindly, Enter in Fields","Warning !", JOptionPane.WARNING_MESSAGE);

			}
			else {
			String query = "INSERT INTO dom_book_flight (full_name,passport,depart,arrival,cnic,class,seat_num,profession,Confirm_b) VALUES ('"+DFget1+"','"+DFget2+"','"+((JComboBox) Departure).getSelectedItem().toString()+"','"+((JComboBox) Arival).getSelectedItem().toString()+"','"+DFget5+"','"+((JComboBox) dropdown).getSelectedItem().toString()+"','"+DFget7+"','"+DFget8+"','"+DFget9+"')";
			st.executeUpdate(query);
			st.executeUpdate(query);
			int input = JOptionPane.showOptionDialog(null, "Domestic Ticket Booked Successfully", "Success !", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
        	if(input == JOptionPane.OK_OPTION)
        	{
        	    new BookingFlights();
        	    DomesticTicket(DFget1,DFget2,((JComboBox) Departure).getSelectedItem().toString(),((JComboBox) dropdown).getSelectedItem().toString(),DFget7,DFget8,DFget9,((JComboBox) Arival).getSelectedItem().toString(),DFget5);
        	}

			st.close();
			con.close();
		}
		}
		catch(Exception ee) {
			System.out.print(ee);
		}

	}
	public static void InterFormBook() {
		String IFget1 = FullName.getText();
		String IFget2 = PassPort.getText();
		Toolkit IFget3 = Departure.getToolkit();
		Toolkit IFget4 = Arival.getToolkit();
		String IFget5 = Cnic.getText();
		Toolkit IFget6  = dropdown.getToolkit();
		String IFget7 = SeatNumber.getText();
		String IFget8 = Profession.getText();
		String IFget9 = ConfirmBrand.getText();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/javaproject","root","1@");
			Statement st = con.createStatement();
			boolean chck1 = (FullName == null || IFget1.length() == 0 );
			boolean chck2 = (PassPort == null || IFget2.length() == 0 );
			boolean chck3 = (Departure == null );
			boolean chck4 = (Arival == null);
			boolean chck5 = (Cnic == null || IFget5.length() == 0 );
			boolean chck6 = (dropdown == null);
			boolean chck7 = (SeatNumber == null || IFget7.length() == 0 );
			boolean chck8 = (Profession == null || IFget8.length() == 0 );
			if(chck1||chck2||chck3||chck4||chck5||chck6||chck7||chck8) {
	         	JOptionPane.showMessageDialog(null, "Kindly, Enter in Fields","Warning !", JOptionPane.WARNING_MESSAGE);

			}
			else {
			String query = "INSERT INTO Inter_book_flight (full_name,passport,depart,arrival,cnic,class,seat_num,profession,Confirm_b) VALUES ('"+IFget1+"','"+IFget2+"','"+((JComboBox) Departure).getSelectedItem().toString()+"','"+((JComboBox) Arival).getSelectedItem().toString()+"','"+IFget5+"','"+((JComboBox) dropdown).getSelectedItem().toString()+"','"+IFget7+"','"+IFget8+"','"+IFget9+"')";
			st.executeUpdate(query);
			int input = JOptionPane.showOptionDialog(null, "International Ticket Booked Successfully", "Success !", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
        	if(input == JOptionPane.OK_OPTION)
        	{
        	    new BookingFlights();
        	    InternationalTicket(IFget1,IFget2,((JComboBox) Departure).getSelectedItem().toString(),((JComboBox) dropdown).getSelectedItem().toString(),IFget7,IFget8,IFget9,((JComboBox) Arival).getSelectedItem().toString(),IFget5);
        	}

			st.close();
			con.close();
		}
		}
		catch(Exception ee) {
			System.out.print(ee);
		}

	}
	public static void CargoFormBook() {
		String CFget1 = CargoName.getText();
		String CFget2 = CargoName.getText();
		Toolkit CFget3 = Departure.getToolkit();
		Toolkit CFget4 = Arival.getToolkit();
		Toolkit CFget5 = classs.getToolkit();
		String CFget6 = Quantity.getText();
		String CFget7 = CargoReady.getText();
		String CFget8 = DesiredDate.getText();
		String CFget9 = ConfirmBrand.getText();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/javaproject","root","1@");
			Statement st = con.createStatement();
			String query = "INSERT INTO cargo_book_flight (cargo_name,description,departure,arrival,class,quantity,cargo_ready,desired_date,confirm_brand) VALUES ('"+CFget1+"','"+CFget2+"','"+((JComboBox) Departure).getSelectedItem().toString()+"','"+((JComboBox) Arival).getSelectedItem().toString()+"','"+((JComboBox) classs).getSelectedItem().toString()+"','"+CFget6+"','"+CFget7+"','"+CFget8+"','"+CFget9+"')";
			st.executeUpdate(query);
			boolean chck1 = (CargoName == null || CFget1.length() == 0 );
			boolean chck2 = (CargoName == null || CFget2.length() == 0 );
			boolean chck3 = (Departure == null );
			boolean chck4 = (Arival == null);
			boolean chck5 = (classs == null);
			boolean chck6 = (Quantity == null || CFget6.length() == 0 );
			boolean chck7 = (CargoReady == null || CFget7.length() == 0 );
			boolean chck8 = (DesiredDate == null || CFget8.length() == 0 );
			if(chck1||chck2||chck3||chck4||chck5||chck6||chck7||chck8) {
	         	JOptionPane.showMessageDialog(null, "Kindly, Enter in Fields","Warning !", JOptionPane.WARNING_MESSAGE);

			}
			else {
//			JOptionPane.showMessageDialog(null, "Registered Successfully","Success !", JOptionPane.INFORMATION_MESSAGE);
			int input = JOptionPane.showOptionDialog(null, "Cargo Ticket Booked Successfully", "Success !", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
        	if(input == JOptionPane.OK_OPTION)
        	{
        	    new BookingFlights();
        	    CargoTicket(CFget1,CFget2,((JComboBox) Departure).getSelectedItem().toString(),CFget6,CFget7,CFget8,CFget9,((JComboBox) Arival).getSelectedItem().toString(),((JComboBox) classs).getSelectedItem().toString());
        	}

			st.close();
			con.close();
		}
		}
		catch(Exception ee) {
			System.out.print(ee);
		}

	}
	public static void main(String[] args) throws Exception {
		new BookingFlights();	
	}
	public void actionPerformed(ActionEvent e){

		if(e.getSource() == LetsGo) {
			DomFormBook();
		}
		else if(e.getSource() == LetsGo2) {
			InterFormBook();
			
		}
		else if(e.getSource() == LetsCargo) {
			CargoFormBook();
			
		}

	}

}


