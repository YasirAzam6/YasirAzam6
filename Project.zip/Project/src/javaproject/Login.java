package javaproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Login implements ActionListener {
	private static JButton SignupBtn;
	private static String UserEmail;
	private static String UserPass;
	private static JTextField txt1;
	private static JTextField SUtxt1;
	private static JTextField SUtxt2;
	private static JTextField SUtxt3;
	private static JPasswordField SUtxt4;
	private static JTextField SUtxt5;
	private static JPasswordField txt2;
	private static JButton DomesticButton;
	private static JButton InternationalButton;
	private static JButton CargoButton;
	private static JButton PIA;
	private static JButton AirBlue;
	private static JButton SereneAir;
	private static JButton QatarAirways;
	private static JButton EmiratesAirline;
	private static JButton INPIA;
	private static JButton INAirBlue;
	private static JButton INSereneAir;
	private static JButton INQatarAirways;
	private static JButton INEmiratesAirline;
	private static JButton CPIA;
	private static JButton CAirBlue;
	private static JButton CSereneAir;
	private static JButton CQatarAirways;
	private static JButton CEmiratesAirline;
	private static JButton DomesticBrands;
	private static JButton InternationalBrands;
	private static JButton UserLoginBtn;
	private static JButton register;
	//Frames
	public static JFrame LoginFrame;
	public static JFrame SelectFlightFrame;
	public static JFrame UserSignupFrame;
	public static JFrame DomesBrandFrame;
	public static JFrame IntBrandFrame;
	public static JFrame CargoBrandFrame;
	public Login(){
		LoginFrame = new JFrame();
		JPanel panel = new JPanel();
		
		Color myColor = Color.decode("#9881F5");
		panel.setBackground(myColor);
		
		UserLoginBtn = new JButton("Login");
		UserLoginBtn.setBackground(Color.decode("#F1F0FF"));
		UserLoginBtn.setForeground(Color.BLACK);
		UserLoginBtn.setBorderPainted(false);
		SignupBtn = new JButton("SignUp");
		SignupBtn.setBackground(Color.decode("#F1F0FF"));
		SignupBtn.setForeground(Color.BLACK);
		SignupBtn.setBorderPainted(false);
		panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
		LoginFrame.setSize(450,400);
		JLabel label1 = new JLabel("Email: ");
		JLabel label2 = new JLabel("Password: ");
		JLabel labelAdmin = new JLabel("Customer Login");
		Font bigFont = labelAdmin.getFont().deriveFont(Font.PLAIN, 50f);
		labelAdmin.setFont(bigFont);
		txt1 = new JTextField(40);
		txt2 = new JPasswordField(40);
		txt1.setPreferredSize(new Dimension(150, 30));
		txt2.setPreferredSize(new Dimension(150, 30));
		UserLoginBtn.setPreferredSize(new Dimension(150, 30));
		SignupBtn.setPreferredSize(new Dimension(150, 30));
		panel.add(labelAdmin);
		panel.add(label1);
		panel.add(txt1);
		panel.add(label2);
		panel.add(txt2);
		panel.add(UserLoginBtn);
		panel.add(SignupBtn);
		UserLoginBtn.addActionListener(this);
		SignupBtn.addActionListener(this);
		LoginFrame.add(panel, BorderLayout.CENTER);
		LoginFrame.setVisible(true);
		LoginFrame.setLocationRelativeTo(null);
		LoginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	public void SelectFlights() {
		LoginFrame.setVisible(false);
		
		SelectFlightFrame = new JFrame();
		Container c1 = SelectFlightFrame.getContentPane();
		Color framecolor = Color.decode("#9881F5");
		c1.setBackground(framecolor);
		
		
		
		DomesticButton = new JButton("Domestic Flights");
		
		DomesticButton.setBackground(Color.decode("#F1F0FF"));
		DomesticButton.setForeground(Color.BLACK);
		DomesticButton.setBorderPainted(false);
		
		DomesticButton.addActionListener(this);
		InternationalButton = new JButton("International Flights");
		
		InternationalButton.setBackground(Color.decode("#F1F0FF"));
		InternationalButton.setForeground(Color.BLACK);
		InternationalButton.setBorderPainted(false);
		
		InternationalButton.addActionListener(this);
		CargoButton = new JButton("Cargo Flights");
		
		CargoButton.setBackground(Color.decode("#F1F0FF"));
		CargoButton.setForeground(Color.BLACK);
		CargoButton.setBorderPainted(false);
		
		CargoButton.addActionListener(this);
		SelectFlightFrame.setPreferredSize(new Dimension(500, 500));
		SelectFlightFrame.setLayout(null);
		DomesticButton.setBounds(140,30,200,40);
		DomesticButton.setSize(200, 50);
		InternationalButton.setBounds(140,150,200,40);
		InternationalButton.setSize(200, 50);
		CargoButton.setBounds(140,270,200,40);
		CargoButton.setSize(200, 50);
		SelectFlightFrame.add(DomesticButton);
		SelectFlightFrame.add(InternationalButton);
		SelectFlightFrame.add(CargoButton);
		SelectFlightFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		SelectFlightFrame.setTitle("Logins");
		SelectFlightFrame.pack();
		SelectFlightFrame.setLocationRelativeTo(null);
		SelectFlightFrame.setVisible(true);
	}
	public static void verifyLoginAdmin() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/javaproject","root","1@");
			Statement st = con.createStatement();
			boolean chck1 = (UserEmail == null || UserEmail.length() == 0 );
			boolean chck2 = (UserPass  == null || UserPass.length() == 0 );
			if (chck1||chck2) {
	         	JOptionPane.showMessageDialog(null, "Kindly, Enter in Fields","Warning !", JOptionPane.WARNING_MESSAGE);
			}
			else {
			String query = "SELECT * FROM users WHERE email = '"+UserEmail+"' AND '"+UserPass+"'";
			ResultSet as = st.executeQuery(query);
			String s2 = "";
			String s3 = "";
			if (as.next()) { 
            s2 = as.getString(3);  
            s3 = as.getString(5);
            System.out.print("Hello");
			}
            if(s2.equals(UserEmail) && s3.equals(UserPass)) {
            	
    			Login a= new Login();
    			a.SelectFlights();
            }
            else {
         	JOptionPane.showMessageDialog(null, "Invalid Credentials","Warning !", JOptionPane.WARNING_MESSAGE);
            }			
		}
		}
		catch(Exception ee) {
			System.out.print(ee);
		}

	}
	
	public static void verifySignUp() {
		String SUget1 = SUtxt1.getText();
		String SUget2 = SUtxt2.getText();
		String SUget3 = SUtxt3.getText();
		String SUget4 = SUtxt4.getText();
		String SUget5 = SUtxt5.getText();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/javaproject","root","1@");
			Statement st = con.createStatement();
			boolean chck1 = (SUtxt1 == null || SUget1.length() == 0 );
			boolean chck2 = (SUtxt2  == null || SUget2.length() == 0 );
			boolean chck3 = (SUtxt3  == null || SUget2.length() == 0 );
			boolean chck4 = (SUtxt4  == null || SUget2.length() == 0 );
			boolean chck5 = (SUtxt5  == null || SUget2.length() == 0 );
			if (chck1||chck2||chck3||chck4||chck5) {
	         	JOptionPane.showMessageDialog(null, "Kindly, Enter in Fields","Warning !", JOptionPane.WARNING_MESSAGE);
			}
			else {
			String query = "INSERT INTO users (full_name,email,cnic, password, contact_no) VALUES ('"+SUget1+"','"+SUget2+"','"+SUget3+"','"+SUget4+"','"+SUget5+"')";
			st.executeUpdate(query);
			int input = JOptionPane.showOptionDialog(null, "Registered Successfully", "Success !", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
        	if(input == JOptionPane.OK_OPTION)
        	{
        		UserSignupFrame.setVisible(false);
        	    new Login();
        	}

			st.close();
			con.close();
		}
		}
		catch(Exception ee) {
			System.out.print(ee);
		}

	}
	public  void UserSignup(){
		LoginFrame.setVisible(false);

		UserSignupFrame = new JFrame();
		JPanel panel = new JPanel();
		
		
		Color framecolor = Color.decode("#9881F5");
		panel.setBackground(framecolor);
		
		register = new JButton("Register Me");
		register.setBackground(Color.decode("#F1F0FF"));
		register.setForeground(Color.BLACK);
		register.setBorderPainted(false);
		
		panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));

		UserSignupFrame.setSize(500,500);
		register.addActionListener(this);
		JLabel SUlabel1 = new JLabel("Full Name: ");
		JLabel SUlabel2 = new JLabel("Email: ");
		JLabel SUlabel3 = new JLabel("CNIC  ( XXXXX-XXXXXXX-X )");
		JLabel SUlabel4 = new JLabel("Password: ");
		JLabel SUlabel5 = new JLabel("Contact No: ");
		JLabel labelAdmin = new JLabel("User SignUp");
		labelAdmin.setPreferredSize(new Dimension(390, 100));
		Font bigFont = labelAdmin.getFont().deriveFont(Font.PLAIN, 50f);

		labelAdmin.setFont(bigFont);
		SUtxt1 = new JTextField(45);
		SUtxt2 = new JTextField(45);
		SUtxt3 = new JTextField(45);
		SUtxt4 = new JPasswordField(45);
		SUtxt5 = new JTextField(45);
		SUtxt1.setPreferredSize(new Dimension(150, 30));
		SUtxt2.setPreferredSize(new Dimension(150, 30));
		SUtxt3.setPreferredSize(new Dimension(150, 30));
		SUtxt4.setPreferredSize(new Dimension(150, 30));
		SUtxt5.setPreferredSize(new Dimension(150, 30));
		register.setPreferredSize(new Dimension(150, 30));
		panel.add(labelAdmin);
		panel.add(SUlabel1);
		panel.add(SUtxt1);
		panel.add(SUlabel2);
		panel.add(SUtxt2);
		panel.add(SUlabel3);
		panel.add(SUtxt3);
		panel.add(SUlabel4);
		panel.add(SUtxt4);
		panel.add(SUlabel5);
		panel.add(SUtxt5);
		panel.add(register);
		UserSignupFrame.add(panel, BorderLayout.CENTER);
		UserSignupFrame.setVisible(true);
		UserSignupFrame.setLocationRelativeTo(null);
		UserSignupFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

}
	public  void DomesticBrands() {
		SelectFlightFrame.setVisible(false);
		DomesBrandFrame = new JFrame();
		
		DomesBrandFrame = new JFrame();
		Container c4 = DomesBrandFrame.getContentPane();
		Color framecolor = Color.decode("#9881F5");
		c4.setBackground(framecolor);
		
		PIA = new JButton("PIA ");
		PIA.addActionListener(this);
		PIA.setBackground(Color.decode("#F1F0FF"));
		PIA.setForeground(Color.BLACK);
		PIA.setBorderPainted(false);
	
		AirBlue = new JButton("AirBlue");
		AirBlue.addActionListener(this);
		AirBlue.setBackground(Color.decode("#F1F0FF"));
		AirBlue.setForeground(Color.BLACK);
		AirBlue.setBorderPainted(false);
		
		SereneAir = new JButton("Serene Air");
		SereneAir.addActionListener(this);
		SereneAir.setBackground(Color.decode("#F1F0FF"));
		SereneAir.setForeground(Color.BLACK);
		SereneAir.setBorderPainted(false);
		
		QatarAirways = new JButton("Qatar Airways");
		QatarAirways.addActionListener(this);
		QatarAirways.setBackground(Color.decode("#F1F0FF"));
		QatarAirways.setForeground(Color.BLACK);
		QatarAirways.setBorderPainted(false);
		
		EmiratesAirline = new JButton("Emirates Airline");
		EmiratesAirline.addActionListener(this);
		EmiratesAirline.setBackground(Color.decode("#F1F0FF"));
		EmiratesAirline.setForeground(Color.BLACK);
		EmiratesAirline.setBorderPainted(false);
		
		DomesBrandFrame.setPreferredSize(new Dimension(500, 450));
		DomesBrandFrame.setLayout(null);
		PIA.setBounds(140,30,200,40);
		PIA.setSize(200, 50);
		AirBlue.setBounds(140,100,200,40);
		AirBlue.setSize(200, 50);
		SereneAir.setBounds(140,180,200,40);
		SereneAir.setSize(200, 50);
		QatarAirways.setBounds(140,260,200,40);
		QatarAirways.setSize(200, 50);
		EmiratesAirline.setBounds(140,340,200,40);
		EmiratesAirline.setSize(200, 50);
		DomesBrandFrame.add(PIA);
		DomesBrandFrame.add(AirBlue);
		DomesBrandFrame.add(SereneAir);
		DomesBrandFrame.add(QatarAirways);
		DomesBrandFrame.add(EmiratesAirline);
		DomesBrandFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		DomesBrandFrame.setTitle("Domestic Airline Brands");
		DomesBrandFrame.pack();
		DomesBrandFrame.setLocationRelativeTo(null);
		DomesBrandFrame.setVisible(true);
	}
	public void InternationalBrands() {
		SelectFlightFrame.setVisible(false);
		IntBrandFrame = new JFrame();
		
		IntBrandFrame = new JFrame();
		Container c5 = IntBrandFrame.getContentPane();
		Color framecolor = Color.decode("#9881F5");
		c5.setBackground(framecolor);
		
		INPIA = new JButton("PIA ");
		INPIA.addActionListener(this);
		INPIA.setBackground(Color.decode("#F1F0FF"));
		INPIA.setForeground(Color.BLACK);
		INPIA.setBorderPainted(false);
		
		
		INAirBlue = new JButton("AirBlue");
		INAirBlue.addActionListener(this);
		INAirBlue.setBackground(Color.decode("#F1F0FF"));
		INAirBlue.setForeground(Color.BLACK);
		INAirBlue.setBorderPainted(false);
		
		INSereneAir = new JButton("Serene Air");
		INSereneAir.addActionListener(this);
		INSereneAir.setBackground(Color.decode("#F1F0FF"));
		INSereneAir.setForeground(Color.BLACK);
		INSereneAir.setBorderPainted(false);
		
		INQatarAirways = new JButton("Qatar Airways");
		INQatarAirways.addActionListener(this);
		INQatarAirways.setBackground(Color.decode("#F1F0FF"));
		INQatarAirways.setForeground(Color.BLACK);
		INQatarAirways.setBorderPainted(false);
		
		INEmiratesAirline = new JButton("Emirates Airline");
		INEmiratesAirline.addActionListener(this);
		INEmiratesAirline.setBackground(Color.decode("#F1F0FF"));
		INEmiratesAirline.setForeground(Color.BLACK);
		INEmiratesAirline.setBorderPainted(false);
		
		IntBrandFrame.setPreferredSize(new Dimension(500, 450));
		IntBrandFrame.setLayout(null);
		INPIA.setBounds(140,30,200,40);
		INPIA.setSize(200, 50);
		INAirBlue.setBounds(140,100,200,40);
		INAirBlue.setSize(200, 50);
		INSereneAir.setBounds(140,180,200,40);
		INSereneAir.setSize(200, 50);
		INQatarAirways.setBounds(140,260,200,40);
		INQatarAirways.setSize(200, 50);
		INEmiratesAirline.setBounds(140,340,200,40);
		INEmiratesAirline.setSize(200, 50);
		IntBrandFrame.add(INPIA);
		IntBrandFrame.add(INAirBlue);
		IntBrandFrame.add(INSereneAir);
		IntBrandFrame.add(INQatarAirways);
		IntBrandFrame.add(INEmiratesAirline);
		IntBrandFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		IntBrandFrame.setTitle("International Airline Brands");
		IntBrandFrame.pack();
		IntBrandFrame.setLocationRelativeTo(null);
		IntBrandFrame.setVisible(true);
	}
	public void CargoBrands() {
		SelectFlightFrame.setVisible(false);
		CargoBrandFrame = new JFrame();
		
		CargoBrandFrame = new JFrame();
		Container c6 = CargoBrandFrame.getContentPane();
		Color framecolor = Color.decode("#9881F5");
		c6.setBackground(framecolor);
		
		CPIA = new JButton("PIA ");
		CPIA.addActionListener(this);
		CPIA.setBackground(Color.decode("#F1F0FF"));
		CPIA.setForeground(Color.BLACK);
		CPIA.setBorderPainted(false);
		
		CAirBlue = new JButton("AirBlue");
		CAirBlue.addActionListener(this);
		CAirBlue.setBackground(Color.decode("#F1F0FF"));
		CAirBlue.setForeground(Color.BLACK);
		CAirBlue.setBorderPainted(false);
		
		CSereneAir = new JButton("Serene Air");
		CSereneAir.addActionListener(this);
		CSereneAir.setBackground(Color.decode("#F1F0FF"));
		CSereneAir.setForeground(Color.BLACK);
		CSereneAir.setBorderPainted(false);
		
		CQatarAirways = new JButton("Qatar Airways");
		CQatarAirways.addActionListener(this);
		CQatarAirways.setBackground(Color.decode("#F1F0FF"));
		CQatarAirways.setForeground(Color.BLACK);
		CQatarAirways.setBorderPainted(false);
		
		CEmiratesAirline = new JButton("Emirates Airline");
		CEmiratesAirline.addActionListener(this);
		CEmiratesAirline.setBackground(Color.decode("#F1F0FF"));
		CEmiratesAirline.setForeground(Color.BLACK);
		CEmiratesAirline.setBorderPainted(false);
		
		
		CargoBrandFrame.setPreferredSize(new Dimension(500, 450));
		CargoBrandFrame.setLayout(null);
		CPIA.setBounds(140,30,200,40);
		CPIA.setSize(200, 50);
		CAirBlue.setBounds(140,100,200,40);
		CAirBlue.setSize(200, 50);
		CSereneAir.setBounds(140,180,200,40);
		CSereneAir.setSize(200, 50);
		CQatarAirways.setBounds(140,260,200,40);
		CQatarAirways.setSize(200, 50);
		CEmiratesAirline.setBounds(140,340,200,40);
		CEmiratesAirline.setSize(200, 50);
		CargoBrandFrame.add(CPIA);
		CargoBrandFrame.add(CAirBlue);
		CargoBrandFrame.add(CSereneAir);
		CargoBrandFrame.add(CQatarAirways);
		CargoBrandFrame.add(CEmiratesAirline);
		CargoBrandFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		CargoBrandFrame.setTitle("Cargo Airline Brands");
		CargoBrandFrame.pack();
		CargoBrandFrame.setLocationRelativeTo(null);
		CargoBrandFrame.setVisible(true);
	}
	public static void main(String[] args) throws Exception {
		
		new Login();
	}
	public void actionPerformed(ActionEvent e){

		 if(e.getSource() == UserLoginBtn) {
			
			UserEmail = txt1.getText();
			UserPass = txt2.getText();
			verifyLoginAdmin();
			txt1.setText("");
			txt2.setText("");
		}
		else if(e.getSource() == SignupBtn) {
			UserSignup();
		}
		else if(e.getSource() == register) {
			verifySignUp();
		}
		else if(e.getSource() == DomesticButton) {
			DomesticBrands();
		}
		else if(e.getSource() == InternationalButton) {
			 InternationalBrands();
		}
		else if(e.getSource() == CargoButton) {
			 CargoBrands();	 
		}
		else if(e.getSource() == PIA) {
			BookingFlights.DomFlightForm();
			String txt = PIA.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == AirBlue) {
			BookingFlights.DomFlightForm();
			String txt = AirBlue.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == SereneAir) {
			BookingFlights.DomFlightForm();
			String txt = SereneAir.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == QatarAirways) {
			BookingFlights.DomFlightForm();
			String txt = QatarAirways.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == EmiratesAirline) {
			BookingFlights.DomFlightForm();
			String txt = EmiratesAirline.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == INPIA) {
			BookingFlights.InterFlightForm();
			String txt = INPIA.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == INAirBlue) {
			BookingFlights.InterFlightForm();
			String txt = INAirBlue.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == INSereneAir) {
			BookingFlights.InterFlightForm();
			String txt = INSereneAir.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == INQatarAirways) {
			BookingFlights.InterFlightForm();
			String txt = INQatarAirways.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == INEmiratesAirline) {
			BookingFlights.InterFlightForm();
			String txt = INEmiratesAirline.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == CPIA) {
			BookingFlights.CargoFlightForm();
			String txt = CPIA.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == CAirBlue) {
			BookingFlights.CargoFlightForm();
			String txt = CAirBlue.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == CSereneAir) {
			BookingFlights.CargoFlightForm();
			String txt = CSereneAir.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == CQatarAirways) {
			BookingFlights.CargoFlightForm();
			String txt = CQatarAirways.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}
		else if(e.getSource() == CEmiratesAirline) {
			BookingFlights.CargoFlightForm();
			String txt = CEmiratesAirline.getText();
			BookingFlights.ConfirmBrand.setText(txt);
		}

	}

}